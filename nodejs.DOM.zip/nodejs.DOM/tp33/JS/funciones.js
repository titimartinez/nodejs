window.addEventListener('load', () => {
    alert("Bienvenido a este sitio.")
})