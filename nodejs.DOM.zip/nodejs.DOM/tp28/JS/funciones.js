function ocultar(objeto) {
    objeto.style.display = 'none'
}