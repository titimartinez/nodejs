function presionParrafo() {
    alert('se presionó el párrafo');
}

function presionCasilla11() {
    alert('se presionó la casilla 1,1');
}

function presionBoton() {
    alert('se presionó el botón');
}