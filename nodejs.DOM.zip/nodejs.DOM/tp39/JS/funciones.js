document.getElementById('buscar').addEventListener('focus', (e) => {
    e.target.value = ''
})