document.getElementById('recuadro').addEventListener('dblclick', (e) => {
    e.target.style.display = 'none'
})
