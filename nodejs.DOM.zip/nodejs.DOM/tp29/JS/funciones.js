function entrada(objeto) {
    objeto.style.color = '#f00'
}

function salida(objeto) {
    objeto.style.color = '#000'
}