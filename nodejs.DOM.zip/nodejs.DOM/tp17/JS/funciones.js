function recuperarAtributo() {
    let puntero = document.getElementById('enlace')
    alert(puntero.getAttribute('href'))
}