function presionar(objeto) {
    objeto.style.backgroundColor = '#ff0'
}

function levantar(objeto) {
    objeto.style.backgroundColor = '#fff'
}